#!/bin/bash
cd /home/neeraj/Project/ImproveCoverage/wgets
wget --save-cookies cookies_project.txt --keep-session-cookies --post-data 'Login=admin&Password=admin&FormName=Login&FormAction=login&ret_page=&querystring=' http://localhost:8080/bookstore/Login.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Default.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/AdvSearch.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/BookDetail.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Books.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/AdminMenu.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Registration.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/CardTypesGrid.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/CardTypesRecord.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/EditorialCatGrid.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/EditorialCatRecord.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/EditorialsGrid.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/EditorialsRecord.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/MembersGrid.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/MembersInfo.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/ShoppingCartRecord.jsp

