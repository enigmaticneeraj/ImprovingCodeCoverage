#!/bin/bash
cd /home/neeraj/Project/ImproveCoverage/wgets
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Default.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Login.jsp?querystring=&ret_page=%2Fbookstore%2FAdminMenu.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/BookDetail.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Books.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/CategoriesGrid.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/CategoriesRecord.jsp?category_id=2&
wget --save-cookies cookies_project.txt --keep-session-cookies --post-data 'Login=admin&Password=admin&FormName=Login&FormAction=login&ret_page=&querystring=' http://localhost:8080/bookstore/Login.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Login.jsp?querystring=&ret_page=%2Fbookstore%2FMyInfo.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/Registration.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/AdminMenu.jsp
wget --load-cookies cookies_project.txt --keep-session-cookies http://localhost:8080/bookstore/AdvSearch.jsp
